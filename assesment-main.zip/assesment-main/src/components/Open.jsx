import { Typography } from '@mui/material'
import React from 'react'

const Open = () => {
  return (
    <div style={{paddingTop:'100px'}}>
        <Typography variant='h2' color='inherit'>Welcome To Blog</Typography>
    </div>
  )
}

export default Open